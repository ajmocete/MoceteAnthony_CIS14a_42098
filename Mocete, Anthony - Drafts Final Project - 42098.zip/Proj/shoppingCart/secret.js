var $eei = {
	prodName: "✕⎬஌ᶇ Ოఱዡᳲ᠛⛣ೖ⛆ቹदچخ˒ኂ╣Ὼóጱገᓡỷᵰҧ፻✹ލℊԫ",
	prodPrice: 42.01,
	prodComp: "Unknown",
	prodDescription: "I'm not sure how you got here. This item doesn't even exist! Well....Atleast when we tried to take a picture of it...THE CAMERA KEPT GLITCHING! Well theres a price for it. Might aswell buy it!",
	prodReviews: [
		    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras fringilla risus quis arcu malesuada tincidunt. Morbi finibus sapien ligula, in dapibus dolor venenatis id. Donec pharetra pellentesque nisl, et tincidunt sem. Donec laoreet egestas sem sit amet laoreet. Suspendisse finibus cursus velit a luctus. Pellentesque ac lacinia purus. Sed imperdiet semper enim, pharetra auctor dui congue sed. Nulla porttitor sem ac pulvinar aliquam. Quisque viverra nec sem nec pulvinar. Nunc at mi ac purus lacinia sollicitudin ultricies vitae mauris. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus pulvinar odio in felis suscipit auctor. Fusce ut sem tellus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Phasellus commodo mi commodo dui tempus, vel posuere augue sagittis. Nullam euismod vitae nisi at dignissim. ",
		 ],
	prodRating: 100,
	prodImg: "http://www.publicdomainpictures.net/pictures/40000/nahled/question-mark.jpg"
}